public class EnterSelectionExceptions extends Exception {

    public String toString()
    {
       return "Кажется вам в голову прилетели пикси. Начните заново.";
    }



}
