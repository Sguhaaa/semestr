public class Line {

    public static void cln() {
        for (int i = 0; i < 50; i++) {
            System.out.println("\n");
        }
    }

    public static void beautiful_line() throws InterruptedException {
        Thread.sleep(3000);
        System.out.println("\n" + "######################################" + "\n");
    }

}
