public class DialogCharacter {
}
